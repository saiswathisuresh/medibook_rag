from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os
from dotenv import load_dotenv
import requests
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchText
from fastembed import TextEmbedding

# ==================== LOAD ENV ====================
load_dotenv()
GROK_API_KEY = os.getenv("GROK_API_KEY")
QDRANT_URL = os.getenv("QDRANT_URL")

# ==================== CONFIG ====================
COLLECTION_NAME = "medical_chunks"
EMBEDDING_MODEL = "BAAI/bge-small-en"
GROK_MODEL = "grok-3"
GROK_URL = "https://api.x.ai/v1/chat/completions"

# ==================== INIT ====================
app = FastAPI(title="Medical Lesson Plan API", version="1.0.0")

# CORS - Frontend access allow
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

qdrant = QdrantClient(url=QDRANT_URL)
embedder = TextEmbedding(model_name=EMBEDDING_MODEL)

# ==================== MODELS ====================
class LessonPlanRequest(BaseModel):
    lesson_plan_name: str
    book_name: str
    chapter_names: List[str]
    top_k: Optional[int] = 15
    max_tokens: Optional[int] = 4000
    temperature: Optional[float] = 0.3

class ChapterLessonPlan(BaseModel):
    chapter_name: str
    content: Optional[str] = None
    error: Optional[str] = None

class LessonPlanResponse(BaseModel):
    lesson_plan_name: str
    book_name: str
    total_chapters: int
    generated_plans: int
    lesson_plans: List[ChapterLessonPlan]

class SearchRequest(BaseModel):
    query: str
    book_name: Optional[str] = None
    top_k: Optional[int] = 5

class SearchResult(BaseModel):
    chunk_id: str
    score: float
    source: str
    book_name: str
    text_preview: str
    full_text: str

class SearchResponse(BaseModel):
    query: str
    book_filter: Optional[str]
    total_results: int
    results: List[SearchResult]

# ==================== HELPER FUNCTIONS ====================
def ask_grok(prompt: str, max_tokens: int = 4000, temperature: float = 0.3):
    """Ask Grok AI for answer"""
    if not prompt.strip():
        return None

    headers = {
        "Authorization": f"Bearer {GROK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": GROK_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    try:
        response = requests.post(GROK_URL, headers=headers, json=payload, timeout=60)
        if response.status_code != 200:
            print(f"Grok API error: {response.status_code} {response.text}")
            return None
        data = response.json()
        return data.get("choices", [{}])[0].get("message", {}).get("content")
    except Exception as e:
        print(f"Grok API error: {e}")
        return None

def extract_keywords(query: str):
    """Extract keywords from query"""
    stop_words = {'what', 'is', 'the', 'a', 'an', 'in', 'on', 'at', 'for', 'to', 'of', 'and', 'or', 'how', 'why'}
    words = query.lower().split()
    keywords = [w.strip('?.,!:') for w in words if w.lower() not in stop_words and len(w) > 2]
    return keywords

def hybrid_search(query: str, book_name: str = None, top_k: int = 15):
    """Hybrid search: Vector + Keyword with optional book filtering"""
    
    # Vector Search with book filter
    query_vector = list(embedder.embed([query]))[0]
    
    search_filter = None
    if book_name:
        search_filter = Filter(
            must=[
                FieldCondition(
                    key="book_name",
                    match=MatchText(text=book_name)
                )
            ]
        )
    
    vector_results = qdrant.search(
        collection_name=COLLECTION_NAME,
        query_vector=query_vector,
        query_filter=search_filter,
        limit=top_k
    )
    
    # Keyword Search
    keywords = extract_keywords(query)
    keyword_results = []
    
    if keywords:
        try:
            for keyword in keywords[:5]:
                filter_conditions = [
                    FieldCondition(
                        key="content",
                        match=MatchText(text=keyword)
                    )
                ]
                
                if book_name:
                    filter_conditions.append(
                        FieldCondition(
                            key="book_name",
                            match=MatchText(text=book_name)
                        )
                    )
                
                results = qdrant.scroll(
                    collection_name=COLLECTION_NAME,
                    scroll_filter=Filter(must=filter_conditions),
                    limit=top_k,
                    with_payload=True
                )[0]
                
                if results:
                    keyword_results.extend(results)
        except Exception as e:
            print(f"Keyword search failed: {e}")
    
    # Combine results
    all_results = {}
    
    for r in vector_results:
        all_results[r.id] = {
            'payload': r.payload,
            'score': r.score,
            'source': 'vector'
        }
    
    for r in keyword_results:
        chunk_id = r.id
        chunk_payload = r.payload if hasattr(r, 'payload') else {}
        
        if chunk_id not in all_results:
            all_results[chunk_id] = {
                'payload': chunk_payload,
                'score': 0.95,
                'source': 'keyword'
            }
        else:
            all_results[chunk_id]['score'] = min(1.0, all_results[chunk_id]['score'] + 0.3)
            all_results[chunk_id]['source'] = 'both'
    
    sorted_results = sorted(all_results.items(), key=lambda x: x[1]['score'], reverse=True)
    return sorted_results[:top_k]

def generate_lesson_plan(chapter_name: str, book_name: str, max_tokens: int = 4000, temperature: float = 0.3):
    """Generate structured lesson plan for a chapter"""
    
    # Search for relevant content
    search_query = f"{chapter_name} {book_name}"
    results = hybrid_search(search_query, book_name=book_name, top_k=15)
    
    if not results:
        return None
    
    # Extract context
    context_chunks = []
    for chunk_id, data in results:
        payload = data.get('payload', {})
        text = payload.get("content") or payload.get("text") or ""
        
        if text and text.strip():
            context_chunks.append(text.strip())
    
    if not context_chunks:
        return None
    
    context = "\n\n".join(context_chunks)[:12000]
    
    # Create lesson plan prompt
    prompt = f"""You are a medical education expert. Create a comprehensive, structured lesson plan based on the content provided.

CONTENT FROM: {book_name}
CHAPTER: {chapter_name}

CONTEXT:
{context}

Generate a detailed lesson plan with the following structure:

1. Learning Objectives
   - List 3-5 specific, measurable learning objectives
   - Use action verbs (understand, identify, explain, analyze, apply)

2. Introduction
   - Brief overview of the topic (2-3 sentences)
   - Why this topic is important for medical students

3. Key Concepts (numbered list)
   - Main topics covered in this chapter
   - Each concept should be a clear heading

4. Detailed Content (for each key concept)
   - Explanation with clinical context
   - Important facts, mechanisms, or processes
   - Clinical correlations where applicable

5. Diagnostic/Clinical Approach (if applicable)
   - Workup steps
   - Diagnostic criteria
   - Differential diagnosis considerations

6. Treatment/Management (if applicable)
   - First-line approaches
   - Alternative strategies
   - Important considerations

7. Key Takeaways
   - 3-5 bullet points summarizing the most important information
   - Focus on high-yield facts for students

Format the response as a clear, structured lesson plan. Use numbered lists and bullet points appropriately. Be comprehensive but concise."""

    # Generate lesson plan
    lesson_plan = ask_grok(prompt, max_tokens=max_tokens, temperature=temperature)
    
    return lesson_plan

# ==================== API ENDPOINTS ====================
@app.get("/")
async def root():
    return {
        "message": "Medical Lesson Plan API",
        "version": "1.0.0",
        "endpoints": [
            "/generate-lesson-plan - POST - Generate lesson plans",
            "/search-content - POST - Search medical content",
            "/health - GET - Check API health"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        collection_info = qdrant.get_collection(COLLECTION_NAME)
        return {
            "status": "healthy",
            "qdrant_connected": True,
            "total_chunks": collection_info.points_count,
            "collection_name": COLLECTION_NAME
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Service unhealthy: {str(e)}")

@app.post("/generate-lesson-plan", response_model=LessonPlanResponse)
async def generate_lesson_plan_api(request: LessonPlanRequest):
    """
    Generate lesson plans for one or more chapters
    
    Example request:
    {
        "lesson_plan_name": "Lymphoma Study Guide",
        "book_name": "ESMO Lymphomas-3rd-edition",
        "chapter_names": ["Chapter 1: Adaptive immunity", "Chapter 2: Innate immunity"],
        "top_k": 15,
        "max_tokens": 4000,
        "temperature": 0.3
    }
    """
    try:
        # Validate input
        if not request.book_name:
            raise HTTPException(status_code=400, detail="book_name is required")
        
        if not request.chapter_names or len(request.chapter_names) == 0:
            raise HTTPException(status_code=400, detail="chapter_names must be a non-empty list")
        
        # Generate lesson plans
        lesson_plans = []
        
        for chapter_name in request.chapter_names:
            print(f"📚 Generating lesson plan for: {chapter_name}")
            
            lesson_plan = generate_lesson_plan(
                chapter_name=chapter_name,
                book_name=request.book_name,
                max_tokens=request.max_tokens,
                temperature=request.temperature
            )
            
            if lesson_plan:
                lesson_plans.append(ChapterLessonPlan(
                    chapter_name=chapter_name,
                    content=lesson_plan
                ))
            else:
                lesson_plans.append(ChapterLessonPlan(
                    chapter_name=chapter_name,
                    content=None,
                    error="No relevant content found or generation failed"
                ))
        
        return LessonPlanResponse(
            lesson_plan_name=request.lesson_plan_name,
            book_name=request.book_name,
            total_chapters=len(request.chapter_names),
            generated_plans=len([p for p in lesson_plans if p.content]),
            lesson_plans=lesson_plans
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.post("/search-content", response_model=SearchResponse)
async def search_content(request: SearchRequest):
    """
    Search for content in medical books
    
    Example request:
    {
        "query": "lymphoma treatment",
        "book_name": "ESMO Lymphomas",
        "top_k": 5
    }
    """
    try:
        if not request.query or len(request.query.strip()) < 3:
            raise HTTPException(status_code=400, detail="Query too short")
        
        # Search
        results = hybrid_search(
            query=request.query,
            book_name=request.book_name,
            top_k=request.top_k
        )
        
        # Format results
        formatted_results = []
        for chunk_id, data in results:
            payload = data.get('payload', {})
            text = payload.get("content") or payload.get("text") or ""
            
            formatted_results.append(SearchResult(
                chunk_id=str(chunk_id),
                score=round(data.get('score', 0), 3),
                source=data.get('source', 'unknown'),
                book_name=payload.get('book_name', 'Unknown'),
                text_preview=text[:200] + "..." if len(text) > 200 else text,
                full_text=text
            ))
        
        return SearchResponse(
            query=request.query,
            book_filter=request.book_name,
            total_results=len(formatted_results),
            results=formatted_results
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# ==================== RUN SERVER ====================
if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Lesson Plan API Server...")
    print(f"📚 Collection: {COLLECTION_NAME}")
    print(f"🔗 Qdrant URL: {QDRANT_URL}")
    print(f"🤖 Model: Grok-3")
    uvicorn.run(app, host="0.0.0.0", port=8002)