from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os
from dotenv import load_dotenv
import requests
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchText
from fastembed import TextEmbedding

# ==================== LOAD ENV ====================
load_dotenv()
GROK_API_KEY = os.getenv("GROK_API_KEY")
QDRANT_URL = os.getenv("QDRANT_URL")

# ==================== CONFIG ====================
COLLECTION_NAME = "medical_chunks"
EMBEDDING_MODEL = "BAAI/bge-small-en"
GROK_MODEL = "grok-3"
GROK_URL = "https://api.x.ai/v1/chat/completions"

# ==================== INIT ====================
app = FastAPI(title="Medical RAG Chat API", version="1.0.0")

# CORS - Frontend access allow பண்ண
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Production la specific domain specify பண்ணுங்க
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

qdrant = QdrantClient(url=QDRANT_URL)
embedder = TextEmbedding(model_name=EMBEDDING_MODEL)

# ==================== MODELS ====================
class ChatRequest(BaseModel):
    question: str
    top_k: Optional[int] = 5
    max_tokens: Optional[int] = 1000
    temperature: Optional[float] = 0.2

class SourceChunk(BaseModel):
    text: str
    score: float
    source: str
    book_id: Optional[str] = None
    chapter_id: Optional[str] = None

class ChatResponse(BaseModel):
    answer: str
    sources: List[SourceChunk]
    found_relevant_content: bool

# ==================== HELPER FUNCTIONS ====================
def ask_grok(prompt: str, max_tokens: int = 1000, temperature: float = 0.2):
    """Ask Grok AI for answer"""
    if not prompt.strip():
        return None

    headers = {
        "Authorization": f"Bearer {GROK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": GROK_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    try:
        response = requests.post(GROK_URL, headers=headers, json=payload, timeout=30)
        if response.status_code != 200:
            return None
        data = response.json()
        return data.get("choices", [{}])[0].get("message", {}).get("content")
    except Exception as e:
        print(f"Grok API error: {e}")
        return None

def extract_keywords(query: str):
    """Extract keywords from query"""
    stop_words = {'what', 'is', 'the', 'a', 'an', 'in', 'on', 'at', 'for', 'to', 'of', 'how', 'why', 'when', 'where'}
    words = query.lower().split()
    keywords = [w.strip('?.,!') for w in words if w.lower() not in stop_words and len(w) > 2]
    return keywords

def hybrid_search(query: str, top_k: int = 5):
    """Hybrid search: Vector + Keyword"""
    
    # Vector Search
    query_vector = list(embedder.embed([query]))[0]
    vector_results = qdrant.search(
        collection_name=COLLECTION_NAME,
        query_vector=query_vector,
        limit=top_k
    )
    
    # Keyword Search
    keywords = extract_keywords(query)
    keyword_results = []
    
    if keywords:
        try:
            for keyword in keywords[:3]:  # Top 3 keywords only
                results = qdrant.scroll(
                    collection_name=COLLECTION_NAME,
                    scroll_filter=Filter(
                        must=[
                            FieldCondition(
                                key="content",  # Your field name
                                match=MatchText(text=keyword)
                            )
                        ]
                    ),
                    limit=top_k,
                    with_payload=True
                )[0]
                
                if results:
                    keyword_results.extend(results)
        except Exception as e:
            print(f"Keyword search failed: {e}")
    
    # Combine results
    all_results = {}
    
    for r in vector_results:
        all_results[r.id] = {
            'payload': r.payload,
            'score': r.score,
            'source': 'vector'
        }
    
    for r in keyword_results:
        chunk_id = r.id
        chunk_payload = r.payload if hasattr(r, 'payload') else {}
        
        if chunk_id not in all_results:
            all_results[chunk_id] = {
                'payload': chunk_payload,
                'score': 0.95,
                'source': 'keyword'
            }
        else:
            all_results[chunk_id]['score'] = min(1.0, all_results[chunk_id]['score'] + 0.3)
            all_results[chunk_id]['source'] = 'both'
    
    sorted_results = sorted(all_results.items(), key=lambda x: x[1]['score'], reverse=True)
    return sorted_results[:top_k]

# ==================== API ENDPOINTS ====================
@app.get("/")
async def root():
    return {
        "message": "Medical RAG Chat API",
        "version": "1.0.0",
        "endpoints": [
            "/chat - POST - Ask medical questions",
            "/health - GET - Check API health"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Check Qdrant connection
        collection_info = qdrant.get_collection(COLLECTION_NAME)
        return {
            "status": "healthy",
            "qdrant_connected": True,
            "total_chunks": collection_info.points_count
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Service unhealthy: {str(e)}")

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Main chat endpoint for medical questions
    
    Example request:
    {
        "question": "What is limb-sparing surgery?",
        "top_k": 5,
        "max_tokens": 1000,
        "temperature": 0.2
    }
    """
    try:
        # Validate input
        if not request.question or len(request.question.strip()) < 3:
            raise HTTPException(status_code=400, detail="Question too short")
        
        # Search for relevant chunks
        results = hybrid_search(request.question, request.top_k)
        
        if not results:
            return ChatResponse(
                answer="I couldn't find relevant information in the medical books. Please try rephrasing your question.",
                sources=[],
                found_relevant_content=False
            )
        
        # Extract context
        context_chunks = []
        source_chunks = []
        
        for chunk_id, data in results:
            payload = data.get('payload', {})
            text = payload.get("content") or payload.get("text") or ""
            
            if text.strip():
                context_chunks.append(text.strip())
                source_chunks.append(SourceChunk(
                    text=text[:500] + "..." if len(text) > 500 else text,
                    score=round(data.get('score', 0.0), 3),
                    source=data.get('source', 'unknown'),
                    book_id=payload.get('book_id'),
                    chapter_id=payload.get('chapter_id')
                ))
        
        if not context_chunks:
            return ChatResponse(
                answer="I found some results but couldn't extract the text content. Please try again.",
                sources=[],
                found_relevant_content=False
            )
        
        # Prepare context
        context = "\n\n".join(context_chunks[:5])  # Top 5 chunks
        context = context[:8000]  # Limit context size
        
        # Create prompt
        prompt = f"""You are a medical assistant helping students learn from medical textbooks.
Answer the question ONLY using the context provided below.
If the answer is not found in the context, say "I don't have information about this in the available medical books."

Be clear, accurate, and educational in your response.

Context:
{context}

Question:
{request.question}

Answer:"""
        
        # Get answer from Grok
        answer = ask_grok(prompt, request.max_tokens, request.temperature)
        
        if not answer:
            raise HTTPException(status_code=500, detail="AI service unavailable")
        
        return ChatResponse(
            answer=answer.strip(),
            sources=source_chunks,
            found_relevant_content=True
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# ==================== RUN SERVER ====================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)