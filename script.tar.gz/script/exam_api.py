from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Literal
from datetime import datetime
import os
from dotenv import load_dotenv
import requests
from qdrant_client import QdrantClient
from fastembed import TextEmbedding
import json
import re

# ==================== LOAD ENV ====================
load_dotenv()
GROK_API_KEY = os.getenv("GROK_API_KEY")
QDRANT_URL = os.getenv("QDRANT_URL")

# ==================== CONFIG ====================
COLLECTION_NAME = "medical_chunks"
EMBEDDING_MODEL = "BAAI/bge-small-en"
GROK_MODEL = "grok-3"
GROK_URL = "https://api.x.ai/v1/chat/completions"

# ==================== INIT ====================
app = FastAPI(title="Medical Exam Generation API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

qdrant = QdrantClient(url=QDRANT_URL)
embedder = TextEmbedding(model_name=EMBEDDING_MODEL)

# ==================== MODELS ====================
class Question(BaseModel):
    question_number: int
    question_text: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str
    correct_answer: Literal["A", "B", "C", "D"]
    marks: int
    explanation: Optional[str] = None

class ExamRequest(BaseModel):
    exam_name: str
    book_name: Optional[str] = "Medical Textbook"
    topic: str
    num_questions: int = 10
    marks_per_question: int = 2
    duration_minutes: Optional[int] = None
    question_type: Literal["book_back", "book_in"] = "book_back"
    difficulty: Optional[Literal["easy", "medium", "hard"]] = "medium"

class ExamResponse(BaseModel):
    exam_name: str
    book_name: str
    topic: str
    date: str
    duration: str
    total_questions: int
    total_marks: int
    questions: List[Question]

# ==================== HELPER FUNCTIONS ====================
def ask_grok(prompt: str, max_tokens: int = 3000, temperature: float = 0.3):
    """Ask Grok AI"""
    if not prompt.strip():
        return None

    headers = {
        "Authorization": f"Bearer {GROK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": GROK_MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    try:
        response = requests.post(GROK_URL, headers=headers, json=payload, timeout=60)
        if response.status_code != 200:
            return None
        data = response.json()
        return data.get("choices", [{}])[0].get("message", {}).get("content")
    except Exception as e:
        print(f"Grok API error: {e}")
        return None

def search_topic_content(topic: str, num_chunks: int = 10):
    """Search for relevant content on a topic"""
    query_vector = list(embedder.embed([topic]))[0]
    
    results = qdrant.search(
        collection_name=COLLECTION_NAME,
        query_vector=query_vector,
        limit=num_chunks
    )
    
    content_chunks = []
    for r in results:
        text = r.payload.get("content") or r.payload.get("text") or ""
        if text.strip():
            content_chunks.append(text.strip())
    
    return "\n\n".join(content_chunks[:num_chunks])

def parse_questions_from_ai(ai_response: str, marks_per_question: int) -> List[Question]:
    """Parse AI-generated questions into structured format"""
    questions = []
    
    # Split by question numbers
    question_blocks = re.split(r'\n(?=Q\d+\.|\d+\.)', ai_response)
    
    question_num = 1
    for block in question_blocks:
        if not block.strip():
            continue
            
        try:
            # Extract question text
            question_match = re.search(r'(?:Q\d+\.|^\d+\.)\s*(.+?)(?=\n[A-D]\))', block, re.DOTALL)
            if not question_match:
                continue
            question_text = question_match.group(1).strip()
            
            # Extract options
            option_a = re.search(r'A\)\s*(.+?)(?=\n[B-D]\)|\nCorrect)', block, re.DOTALL)
            option_b = re.search(r'B\)\s*(.+?)(?=\n[C-D]\)|\nCorrect)', block, re.DOTALL)
            option_c = re.search(r'C\)\s*(.+?)(?=\nD\)|\nCorrect)', block, re.DOTALL)
            option_d = re.search(r'D\)\s*(.+?)(?=\nCorrect)', block, re.DOTALL)
            
            # Extract correct answer
            correct_match = re.search(r'Correct Answer:\s*([A-D])', block)
            
            # Extract explanation (optional)
            explanation_match = re.search(r'Explanation:\s*(.+?)(?=\n\n|$)', block, re.DOTALL)
            
            if all([option_a, option_b, option_c, option_d, correct_match]):
                questions.append(Question(
                    question_number=question_num,
                    question_text=question_text,
                    option_a=option_a.group(1).strip(),
                    option_b=option_b.group(1).strip(),
                    option_c=option_c.group(1).strip(),
                    option_d=option_d.group(1).strip(),
                    correct_answer=correct_match.group(1),
                    marks=marks_per_question,
                    explanation=explanation_match.group(1).strip() if explanation_match else None
                ))
                question_num += 1
        except Exception as e:
            print(f"Error parsing question block: {e}")
            continue
    
    return questions

# ==================== API ENDPOINTS ====================
@app.get("/")
async def root():
    return {
        "message": "Medical Exam Generation API",
        "version": "1.0.0",
        "endpoints": [
            "/generate-exam - POST - Generate exam questions",
            "/health - GET - Check API health"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check"""
    try:
        collection_info = qdrant.get_collection(COLLECTION_NAME)
        return {
            "status": "healthy",
            "qdrant_connected": True,
            "total_chunks": collection_info.points_count
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Service unhealthy: {str(e)}")

@app.post("/generate-exam", response_model=ExamResponse)
async def generate_exam(request: ExamRequest):
    """
    Generate exam questions based on topic
    
    Example request:
    {
        "exam_name": "Oncology Midterm",
        "book_name": "NCCN Cancer Guidelines",
        "topic": "breast cancer treatment",
        "num_questions": 10,
        "marks_per_question": 2,
        "duration_minutes": 30,
        "question_type": "book_back",
        "difficulty": "medium"
    }
    """
    try:
        # Validate input
        if request.num_questions < 1 or request.num_questions > 50:
            raise HTTPException(status_code=400, detail="Number of questions must be between 1 and 50")
        
        if not request.topic or len(request.topic.strip()) < 3:
            raise HTTPException(status_code=400, detail="Topic is required")
        
        # Search for relevant content
        topic_content = search_topic_content(request.topic, num_chunks=15)
        
        if not topic_content:
            raise HTTPException(
                status_code=404, 
                detail=f"No content found for topic: {request.topic}"
            )
        
        # Generate questions based on type
        if request.question_type == "book_back":
            # Generate questions STRICTLY from book content
            prompt = f"""You are creating a medical exam from textbook content.

Generate EXACTLY {request.num_questions} multiple choice questions (MCQs) based ONLY on the content provided below.

STRICT RULES:
1. Every question and answer MUST come directly from the provided content
2. Do NOT create questions from general medical knowledge
3. Questions should test understanding of the specific content provided
4. Difficulty level: {request.difficulty}
5. Each question must have exactly 4 options (A, B, C, D)
6. Only ONE option should be correct

Content from textbook about "{request.topic}":
{topic_content[:6000]}

FORMAT (use exactly this format):
Q1. [Question text here]?
A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]
Correct Answer: [A/B/C/D]

Q2. [Next question]
...

Generate {request.num_questions} questions now:"""

        else:  # book_in - AI generated but topic-related
            prompt = f"""You are creating a medical exam on the topic: "{request.topic}"

Using the provided textbook content as context, generate EXACTLY {request.num_questions} multiple choice questions that test deeper understanding and application of concepts.

Rules:
1. Use the textbook content to understand the topic thoroughly
2. Create questions that test application, analysis, and clinical reasoning
3. Questions can go beyond the exact text but must stay within the topic domain
4. Difficulty level: {request.difficulty}
5. Each question must have exactly 4 options (A, B, C, D)
6. Only ONE option should be correct

Reference content about "{request.topic}":
{topic_content[:6000]}

FORMAT (use exactly this format):
Q1. [Question text here]?
A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]
Correct Answer: [A/B/C/D]

Q2. [Next question]
...

Generate {request.num_questions} questions now:"""
        
        # Get AI response
        ai_response = ask_grok(prompt, max_tokens=3000, temperature=0.3)
        
        if not ai_response:
            raise HTTPException(status_code=500, detail="Failed to generate questions from AI")
        
        # Parse questions
        questions = parse_questions_from_ai(ai_response, request.marks_per_question)
        
        if len(questions) < request.num_questions:
            print(f"Warning: Only generated {len(questions)} out of {request.num_questions} requested")
        
        if not questions:
            raise HTTPException(status_code=500, detail="Failed to parse generated questions")
        
        # Create exam response
        total_marks = len(questions) * request.marks_per_question
        duration_str = f"{request.duration_minutes} minutes" if request.duration_minutes else "N/A minutes"
        
        return ExamResponse(
            exam_name=request.exam_name,
            book_name=request.book_name,
            topic=request.topic,
            date=datetime.now().strftime("%Y-%m-%d"),
            duration=duration_str,
            total_questions=len(questions),
            total_marks=total_marks,
            questions=questions
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# ==================== RUN SERVER ====================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)  # Different port from chat API